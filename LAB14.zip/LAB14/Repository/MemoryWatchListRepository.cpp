//
// Created by Sorin Sebastian Mircea on 28/04/2017.
//

#include "MemoryWatchListRepository.h"

void MemoryWatchListRepository::loadCustom() {

}

void MemoryWatchListRepository::saveCustom() {

}

void MemoryWatchListRepository::save() {
}
